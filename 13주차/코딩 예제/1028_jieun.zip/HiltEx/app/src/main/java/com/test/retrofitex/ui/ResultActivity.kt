package com.test.retrofitex.ui

import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.test.retrofitex.databinding.ActivityResultBinding
import com.test.retrofitex.viewmodel.NasaViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ResultActivity : AppCompatActivity() {

    lateinit var activityResultBinding: ActivityResultBinding

    private val nasaViewModel : NasaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        activityResultBinding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(activityResultBinding.root)

        val resultDate = getIntentString("date")
        val resultExplanation = getIntentString("explanation")
        val resultHdurl = getIntentString("hdurl")
        var resultTitle = getIntentString("title")

        nasaViewModel.run {
            apodDate.observe(this@ResultActivity){
                activityResultBinding.textViewResultDate.text = it
            }
            apodTitle.observe(this@ResultActivity){
                activityResultBinding.textViewResultTitle.text = it
            }
            apodHdurl.observe(this@ResultActivity){
                Glide.with(this@ResultActivity).load(it)
                    .listener(object : RequestListener<Drawable>{
                        override fun onLoadFailed(
                            e: GlideException?,
                            model: Any?,
                            target: Target<Drawable>?,
                            isFirstResource: Boolean
                        ): Boolean {
                            activityResultBinding.progressBarResult.visibility = View.GONE
                            return false
                        }

                        override fun onResourceReady(
                            resource: Drawable?,
                            model: Any?,
                            target: Target<Drawable>?,
                            dataSource: DataSource?,
                            isFirstResource: Boolean
                        ): Boolean {
                            activityResultBinding.progressBarResult.visibility = View.GONE
                            return false
                        }
                    })
                    .into(activityResultBinding.imageViewResult)
            }
            apodExplanation.observe(this@ResultActivity){
                activityResultBinding.textViewResultExplanation.text = it
            }
        }

        nasaViewModel.apodDate.value = resultDate
        nasaViewModel.apodTitle.value = resultTitle
        nasaViewModel.apodExplanation.value = resultExplanation
        nasaViewModel.apodHdurl.value = resultHdurl

        activityResultBinding.run {
            progressBarResult.visibility = View.VISIBLE
            materialToolbarResult.run{
                title = "NASA - APOD"

                setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
                setNavigationOnClickListener { finish() }
            }
        }
    }

    fun getIntentString(string: String) : String?{
        return intent.getStringExtra(string)
    }
}