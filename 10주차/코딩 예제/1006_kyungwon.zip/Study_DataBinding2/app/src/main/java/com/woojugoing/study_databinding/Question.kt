package com.woojugoing.study_databinding

data class Question(
    val que: String,
    val sol: String
)