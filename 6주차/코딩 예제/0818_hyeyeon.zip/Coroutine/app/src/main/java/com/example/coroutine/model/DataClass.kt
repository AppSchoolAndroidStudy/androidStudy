package com.example.coroutine.model

data class DataClass(var image: String, var title: String, var description: String)