package com.test.musicplayproject

const val MEDIA_PLAYER_PLAY = "play"
const val MEDIA_PLAYER_PAUSE = "pause"
const val MEDIA_PLAYER_STOP = "stop"
