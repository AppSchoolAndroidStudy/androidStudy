package com.test.study08_junit

class Caculate {
    fun add(num1 : Int, num2:Int) : Int{
        return num1 + num2
    }
    fun substract(num1 : Int, num2:Int) : Int{
        return num1 - num2
    }
    fun multiply(num1 : Int, num2:Int) : Int{
        return num1 * num2
    }
}