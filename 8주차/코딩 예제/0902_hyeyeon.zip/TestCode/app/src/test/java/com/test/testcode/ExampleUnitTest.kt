package com.test.testcode

import org.junit.Test

import org.junit.Assert.*

class ExampleUnitTest {

    @Test
    fun testValidLogin() {
        val loginFragment = LoginFragment()

        val result = loginFragment.login("hyeyeon@naver.com", "1234")

        assertTrue(result)
    }

    @Test
    fun testInvalidLogin() {
        val loginFragment = LoginFragment()

        val result = loginFragment.login("invalid_user", "invalid_password")

        assertFalse(result)
    }
}
