package com.test.retrofitex.data.model

data class APOD(
    var date : String,
    var explanation : String,
    var hdurl : String,
    var title : String
)