package com.test.mvvmbasic.model

//model : 애플리케이션에서 사용되는 모든 데이터를 담을 클래스들을 정의한다.

data class TestDataClass(var testIdx:Int = 0, var testData1:String, var testData2:String)