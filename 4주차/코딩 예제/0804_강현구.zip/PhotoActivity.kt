package com.test.carouselproject

import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.github.chrisbanes.photoview.PhotoView

class PhotoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_photo)




        val photoView=findViewById<PhotoView>(R.id.photoView)
        photoView.setImageBitmap(MainActivity.touchedBitmap)
    }
}