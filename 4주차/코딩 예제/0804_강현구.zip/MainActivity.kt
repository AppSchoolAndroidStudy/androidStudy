package com.test.carouselproject

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.widget.ImageView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.carousel.CarouselLayoutManager
import com.test.carouselproject.databinding.ActivityMainBinding
import com.test.carouselproject.databinding.RecyclerItemBinding
import com.test.carouselproject.databinding.RowBinding

class MainActivity : AppCompatActivity() {
    lateinit var activityMainBinding: ActivityMainBinding
    companion object{
        lateinit var touchedBitmap: Bitmap
    }
    //사진 선택 결과를 받아오는 런쳐
    val permissionList = arrayOf(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.ACCESS_MEDIA_LOCATION,
        Manifest.permission.INTERNET
    )
    private lateinit var activityResultLauncher: ActivityResultLauncher<Intent>

    var imageList = mutableListOf<Bitmap>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(activityMainBinding.root)
        requestPermissions(permissionList, 0)

        //런쳐 초기화
        val activityContract = ActivityResultContracts.StartActivityForResult()
        activityResultLauncher = registerForActivityResult(activityContract) {
            if (it.resultCode == RESULT_OK) {
                //사진 여러장 선택했을 때
                if (it.data?.clipData != null) {
                    //선택 이미지 갯수
                    val count = it.data?.clipData?.itemCount
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        for (index in 0 until count!!) {
                            val imageUri = it.data?.clipData?.getItemAt(index)?.uri
                            val source =
                                ImageDecoder.createSource(this@MainActivity.contentResolver, imageUri!!)
                            val bitmap = ImageDecoder.decodeBitmap(source)

                            //이미지 닫기
                            imageList.add(scaleBitmapToViewSize(bitmap,2000,1200))
                        }
                    }
                    //사진 한장 선택했을 때
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val imageUri = it.data?.data
                        val source =
                            ImageDecoder.createSource(this@MainActivity.contentResolver, imageUri!!)
                        val bitmap = ImageDecoder.decodeBitmap(source)
                        imageList.add(scaleBitmapToViewSize(bitmap,2000,1200))
                    }
                }
                val adapter = activityMainBinding.carouselRecyclerView.adapter as RecyclerAdapter
                adapter.notifyDataSetChanged()
//                for(bitmap in imageList){
//                    Log.d("testt",bitmap.toString())
//                }
            }
        }

        activityMainBinding.materialToolbar.run {
            title = "다중 사진 선택"
            setTitleTextColor(Color.WHITE)
            inflateMenu(R.menu.main_menu)

            setOnMenuItemClickListener {
                when (it.itemId) {
                    R.id.take_picture_item -> {}
                    R.id.take_from_album_item -> {
                        val intent = Intent(Intent.ACTION_PICK)
                        intent.type = "image/*"
                        //사진 여러개 선택 기능
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        activityResultLauncher.launch(intent)
                    }
                }
                true
            }
        }
        activityMainBinding.carouselRecyclerView.run {
            adapter = RecyclerAdapter()
            layoutManager = CarouselLayoutManager()
        }
    }

    fun scaleBitmapToViewSize(bitmap: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        val originalWidth = bitmap.width
        val originalHeight = bitmap.height

        // 비율 계산
        val scaleX = targetWidth.toFloat() / originalWidth
        val scaleY = targetHeight.toFloat() / originalHeight
        val scale = if (scaleX < scaleY) scaleX else scaleY

        // 크기 조정을 위한 Matrix 생성
        val matrix = Matrix()
        matrix.postScale(scale, scale)

        // 크기 조정된 비트맵 생성
        return Bitmap.createBitmap(bitmap, 0, 0, originalWidth, originalHeight, matrix, true)
    }


    inner class RecyclerAdapter : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {
        inner class ViewHolder(recyclerItemBinding: RecyclerItemBinding) :
            RecyclerView.ViewHolder(recyclerItemBinding.root) {
            val caroucelImageView: ImageView

            init {
                caroucelImageView = recyclerItemBinding.carouselImageView
                recyclerItemBinding.root.setOnClickListener {
                    startActivity(Intent(Intent(this@MainActivity,PhotoActivity::class.java)))
                    touchedBitmap=imageList[adapterPosition]
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val recyclerItemBinding = RecyclerItemBinding.inflate(layoutInflater)
            val viewHolderClass = ViewHolder(recyclerItemBinding)

            return viewHolderClass
        }

        override fun getItemCount(): Int {
            return imageList.size
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
           holder.caroucelImageView.setImageBitmap(imageList[position])
        }
    }
}