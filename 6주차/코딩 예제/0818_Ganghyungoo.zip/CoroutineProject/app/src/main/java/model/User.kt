package model

data class User(var userIdx: Long, var id: String, var password: String)