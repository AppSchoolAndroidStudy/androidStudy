package com.qure.calculator_tdd.presentation

import dagger.hilt.android.HiltAndroidApp
import android.app.Application

@HiltAndroidApp
class CalculatorApplication : Application()