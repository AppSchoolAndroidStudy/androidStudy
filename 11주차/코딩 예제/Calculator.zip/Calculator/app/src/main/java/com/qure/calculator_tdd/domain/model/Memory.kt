package com.qure.calculator_tdd.domain.model

data class Memory(
    val expression: String,
    val result: String
)