package com.woojugoing.android74_memoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.woojugoing.android74_memoapp.databinding.ActivityMainBinding
import kotlin.concurrent.thread

// [ AndroidManifest.xml label, icon 설정 ]
// label : 아이콘 하단에 표시 되는 앱의 이름
// icon, roundIcon : 앱 아이콘

class MainActivity : AppCompatActivity() {

    private lateinit var activityMainBinding: ActivityMainBinding

    companion object{
        val PASSWORD_FRAGMENT = "PasswordFragment"
        val LOGIN_FRAGMENT = "LoginFragment"
        val CATEGORY_MAIN_FRAGMENT = "CategoryMainFragment"
        val MEMO_MAIN_FRAGMENT = "MemoMainFragment"
        val MEMO_ADD_FRAGMENT = "MemoAddFragment"
        val MEMO_READ_FRAGMENT = "MemoReadFragment"
        val MEMO_EDIT_FRAGMENT = "MemoEditFragment"
    }

    lateinit var inputMethodManager: InputMethodManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // SplashScreen 적용 - setContentView 전에 작성 해야 함
        installSplashScreen()

        activityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(activityMainBinding.root)
        inputMethodManager = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager

        // 저장된 비밀번호를 가져옴 - 비밀번호 설정 여부에 따라서 처음에 보여줄 Fragment를 다르게 지정한다.
        // val passwordList = PasswordDAO.selectAll(this)
        val pref = getSharedPreferences("data", MODE_PRIVATE)
        val password = pref.getString("password", null)
        // if(passwordList.size == 0)
        if(password == null){
            replaceFragment(PASSWORD_FRAGMENT, addToBackStack = false, animate = false)
        } else {
            replaceFragment(LOGIN_FRAGMENT, addToBackStack = false, animate = false)
        }

        val dbHelper = DBHelper(this)
        dbHelper.writableDatabase
        dbHelper.close()
    }

    fun replaceFragment(name:String, addToBackStack:Boolean, animate:Boolean, arguments: Bundle? = null){
        SystemClock.sleep(200)
        val fragmentTransaction = supportFragmentManager.beginTransaction()

        val newFragment = when(name){
            PASSWORD_FRAGMENT -> PasswordFragment()
            LOGIN_FRAGMENT -> LoginFragment()
            CATEGORY_MAIN_FRAGMENT -> CategoryMainFragment()
            MEMO_MAIN_FRAGMENT -> MemoMainFragment()
            MEMO_ADD_FRAGMENT -> MemoAddFragment()
            MEMO_READ_FRAGMENT -> MemoReadFragment()
            MEMO_EDIT_FRAGMENT -> MemoEditFragment()
            else -> Fragment()
        }

        // Fragment Bundle Setting
        newFragment.arguments = arguments

        if(newFragment != null) {
            if (animate) {
                fragmentTransaction.setCustomAnimations(
                    // A -> B ( B가 나타날 때 )
                    R.anim.slide_in,
                    // A가 사라질 때
                    R.anim.fade_out,
                    // A가 나타날 때
                    R.anim.fade_in,
                    // B가 사라질 때
                    R.anim.slide_out
                )
            }

            fragmentTransaction.replace(R.id.container_main, newFragment)

            if (addToBackStack) {
                fragmentTransaction.addToBackStack(name)
            }
            fragmentTransaction.commit()
        }
    }

    // BackStack 에서 제거
    fun removeFragment(name:String){
        SystemClock.sleep(200)
        supportFragmentManager.popBackStack(name, FragmentManager.POP_BACK_STACK_INCLUSIVE)
    }

    // Keyboard 를 올려줌
    fun showSoftInput(view: View, delay: Long){
        view.requestFocus()
        thread {
            SystemClock.sleep(delay)
            inputMethodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    fun hideSoftInput() {
        if(currentFocus != null) {
            inputMethodManager.hideSoftInputFromWindow(currentFocus?.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
        }
    }
}

// Table의 Data를 담을 data class
data class PasswordClass(var passwordIdx: Int, var passwordData: String)
data class CategoryClass(var categoryIdx: Int, var categoryName: String)
data class MemoClass(var memoIdx: Int, var memoTitle: String, var memoContent: String, var memoDate: String, var memoCatIdx: Int)