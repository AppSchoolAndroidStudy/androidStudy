package com.test.compose

data class Photo (
    val title: String,
    val date: String,
    val image: Int,
    val content: String
)
