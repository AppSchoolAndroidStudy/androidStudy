package com.woojugoing.jetpack01_practice

data class Dog(
    val id: Int,
    val dogName: String,
    val dogAct: String,
    val img: Int
)