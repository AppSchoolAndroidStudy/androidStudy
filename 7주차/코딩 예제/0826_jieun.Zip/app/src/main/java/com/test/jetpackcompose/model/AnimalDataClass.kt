package com.test.jetpackcompose.model

data class AnimalDataClass(
    val name : String,      //이름
    val image : Int,        //이미지
    val content : String    //내용
)