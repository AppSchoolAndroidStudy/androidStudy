package com.test.android_naverapiex

import android.app.appsearch.AppSearchManager.SearchContext
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.TextView
import android.widget.Toast
import android.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.divider.MaterialDividerItemDecoration
import com.test.android_naverapiex.databinding.ActivityMainBinding
import com.test.android_naverapiex.databinding.RowBinding
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.Serializable
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.net.ssl.HttpsURLConnection
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    lateinit var activityMainBinding: ActivityMainBinding

    //기사 데이터 리스트
    val articleList = mutableListOf<Article>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        activityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(activityMainBinding.root)

        activityMainBinding.run {
            //editText 엔터키 이벤트(에뮬레이터 키보드로만 작동)
            textInputEditTextMainSearch.setOnEditorActionListener { textView, i, keyEvent ->
                val keyWord = textInputEditTextMainSearch.text.toString()
                //입력된 검색 키워드 인코딩 설정
                val searchWord = URLEncoder.encode(keyWord, "UTF-8")

                //리스트 초기화
                articleList.clear()
                //기사 목록 불러오는 함수
                getArticleObject(searchWord)

                false
            }

            toolbarMain.run {
                title = "네이버 API 뉴스 검색"
                setTitleTextColor(Color.BLACK)
            }

            recyclerViewMain.run {
                adapter = RecyclerViewAdapter()
                layoutManager = LinearLayoutManager(this@MainActivity)

                //material divider 설정
                val divider = MaterialDividerItemDecoration(this@MainActivity, LinearLayoutManager.VERTICAL)
                divider.run {
                    setDividerColorResource(this@MainActivity, R.color.green)
                    dividerInsetStart = 70
                    dividerInsetEnd = 70
                }
                addItemDecoration(divider)
            }
        }
    }

    inner class RecyclerViewAdapter: RecyclerView.Adapter<RecyclerViewAdapter.ViewHolderClass>(){
        inner class ViewHolderClass (rowBinding: RowBinding) : RecyclerView.ViewHolder(rowBinding.root){
            val textViewRowTitle : TextView
            val textViewRowDate : TextView
            init {
                textViewRowTitle = rowBinding.textViewRowTitle
                textViewRowDate = rowBinding.textViewRowDate

                //리사이클러뷰 항목 클릭 이벤트
                rowBinding.root.setOnClickListener {
                    //bundle 객체를 통해 선택된 기사 객체를 저장
                    var newBundle = Bundle()
                    newBundle.putSerializable("article", articleList[adapterPosition])

                    val newIntent = Intent(this@MainActivity, ShowArticleActivity::class.java)
                    //저장된 bundle 객체를 intent에 담아 보냄
                    newIntent.putExtra("newBundle", newBundle)
                    startActivity(newIntent)
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderClass {
            val rowBinding = RowBinding.inflate(layoutInflater)
            val viewHolderClass = ViewHolderClass(rowBinding)

            rowBinding.root.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            return viewHolderClass
        }

        override fun getItemCount(): Int {
            return articleList.size
        }

        override fun onBindViewHolder(holder: ViewHolderClass, position: Int) {
            holder.textViewRowTitle.text = articleList[position].title
            holder.textViewRowDate.text = articleList[position].pubDate
        }
    }

    //불러온 기사 제목 데이터의 특수기호 처리
    fun fixTitle(title:String) : String {
        val t1 = title.replace("<b>", "")
        val t2 = t1.replace("</b>", "")
        val t3 = t2.replace("&quot;", "\"")
        val t4 = t3.replace("&apos;", "\'")

        val t5 = t4.replace("&amp", "&")
        val t6 = t5.replace("&lt", "<")
        val t7 = t6.replace("&gt", ">")

        return t7
    }

    //불러온 기사 날짜 데이터의 처리
    fun fixDate(date:String):String{
        val idx = date.indexOf("+")

        if(idx==-1){
            return date
        }else{
            val newDate = date.removeRange(idx-4 until date.length)
            return newDate
        }
    }

    //naver api 설정해 json 데이터 받아오는 함수
    fun getArticleObject(searchWord:String){
        thread {
            //검색할 키워드가 설정된 주소
            val address =
                "https://openapi.naver.com/v1/search/news.json?query=${searchWord}&display=20&start=1&sort=sim"

            //애플리케이션 client id와 client secret
            val clientId = "Km9MrCAr_22YXLYK2kK5"
            val clientSecret = "SP3ibh3X86"

            val url = URL(address)
            val httpUrlConnection = url.openConnection() as HttpURLConnection
            //헤더 전달 방식 설정
            httpUrlConnection.requestMethod = "GET"
            //헤더 정보 설정
            httpUrlConnection.setRequestProperty("X-Naver-Client-Id", clientId)
            httpUrlConnection.setRequestProperty("X-Naver-Client-Secret", clientSecret)

            //서버 응답 코드
            val responseCode = httpUrlConnection.responseCode

            lateinit var inputStreamReader: InputStreamReader
            //200 : 성공
            if (responseCode == 200) {
                inputStreamReader =
                    InputStreamReader(httpUrlConnection.inputStream, "UTF-8")
                Log.d("NormalResponse", responseCode.toString())
            } else {
                Log.e("ErrorResponse", responseCode.toString())
            }

            //모든 데이터를 읽어옴
            val data = inputStreamReader.buffered().use { it.readText() }

            //필요한 데이터만 추출
            val root = JSONObject(data)

            val itemArray = root.getJSONArray("items")

            for (idx in 0 until itemArray.length()) {
                val item = itemArray.getJSONObject(idx)

                val title = item.getString("title")
                val link = item.getString("link")
                val pubDate = item.getString("pubDate")

                //제목과 날짜 데이터 처리
                val fixedTitle = fixTitle(title)
                val fixedDate = fixDate(pubDate)

                //기사 객체 생성해 리스트에 추가
                articleList.add(Article(fixedTitle, link, fixedDate))
            }

            //리싸이클러뷰 갱신 명령
            runOnUiThread {
                activityMainBinding.recyclerViewMain.adapter?.notifyDataSetChanged()
            }
        }
    }

}

//기사 클래스
data class Article(val title:String, val link:String, val pubDate:String) : Serializable