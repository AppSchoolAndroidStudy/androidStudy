package com.test.android_naverapiex

import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.view.WindowInsetsControllerCompat
import com.test.android_naverapiex.databinding.ActivityShowArticleBinding

class ShowArticleActivity : AppCompatActivity() {

    lateinit var activityShowArticleBinding: ActivityShowArticleBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        activityShowArticleBinding = ActivityShowArticleBinding.inflate(layoutInflater)
        setContentView(activityShowArticleBinding.root)

        //상태바 배경 및 아이콘 색상 설정
        window.statusBarColor = getColor(com.google.android.material.R.color.material_dynamic_tertiary99)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        //이전 액티비티로 부터 전달받은 객체 추출
        val bundle = intent.getBundleExtra("newBundle")
        val article = if(Build.VERSION.SDK_INT == Build.VERSION_CODES.TIRAMISU){
            bundle?.getSerializable("article", Article::class.java)
        }else{
            bundle?.getSerializable("article") as Article
        }

        activityShowArticleBinding.run {

            //웹뷰 설정
            webView.webViewClient = WebViewClient()
            webView.webChromeClient = WebChromeClient()
            webView.loadUrl(article?.link!!)

            toolbarShowArticle.run {
                title = "선택된 기사"
                setTitleTextColor(Color.BLACK)

                //백버튼 설정
                setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
                setNavigationOnClickListener {
                    finish()
                }
            }
        }
    }
}