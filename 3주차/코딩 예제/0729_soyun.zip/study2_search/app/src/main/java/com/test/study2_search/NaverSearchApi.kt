package com.test.study2_search

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query


// 네이버 검색 API를 호출하기 위한 API 인터페이스
interface NaverSearchApi {
    //GET 메서드를 사용하여 네이버 검색 API의 "/v1/search/blog" 에 요청
    @GET("/v1/search/blog")
    fun searchBlogs(
        //@Query 어노테이션을 사용하여 쿼리 파라미터를 설정
        @Query("query") keyword: String,
        @Query("display") display: Int,
        @Query("start") start: Int,

        //@Header 어노테이션을 사용하여 클라이언트 ID와 클라이언트 시크릿을 요청 헤더에 포함
        @Header("X-Naver-Client-Id") clientId: String = "KqCQcJxD5iFkIZ81nLtb",
        @Header("X-Naver-Client-Secret") clientSecret: String = "xP2xKmpThS"
    ): Call<ApiResponse>
}