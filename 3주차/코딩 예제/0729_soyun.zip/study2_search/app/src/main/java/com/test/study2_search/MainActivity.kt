package com.test.study2_search

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.test.study2_search.databinding.ActivityMainBinding
import com.test.study2_search.databinding.RowMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    var searchItems = mutableListOf<SearchItem>()

    // lazy : 처음으로 해당 속성이 접근될 때까지 초기화를 미루다가 실제로 접근이 필요한 시점에서 초기화를 수행
    private val naverSearchApi: NaverSearchApi by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://openapi.naver.com")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        //생성된 Retrofit 객체를 사용하여 NaverSearchApi 인터페이스의 구현체를 생성하여 반환
        retrofit.create(NaverSearchApi::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.run{
            searchButton.setOnClickListener {
                val searchKeyword = searchEditText.text.toString()
                if (searchKeyword.isNotBlank()) {
                    searchBlogs(searchKeyword)
                } else {
                    Toast.makeText(this@MainActivity, "검색어를 입력해주세요.", Toast.LENGTH_SHORT).show()
                }
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(binding.searchEditText.windowToken, 0)

            }

            recyclerViewMain.run{
                adapter = MainRecyclerViewAdapter()
                layoutManager = LinearLayoutManager(this@MainActivity)
                addItemDecoration(DividerItemDecoration(this@MainActivity, DividerItemDecoration.VERTICAL))
            }
        }
    }

    private fun searchBlogs(keyword: String) {
        val call = naverSearchApi.searchBlogs(keyword, 10, 1)

        // Retrofit 라이브러리에서 비동기적인 HTTP 요청을 실행하는 메서드
        call.enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                if (response.isSuccessful) {
                    val apiResponse = response.body()
                    apiResponse?.let {
                        searchItems = it.items as MutableList<SearchItem>
                    }
                } else {
                    Toast.makeText(this@MainActivity, "검색 결과를 가져오지 못했습니다.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                Toast.makeText(this@MainActivity, "네트워크 오류가 발생했습니다.", Toast.LENGTH_SHORT).show()
            }
        })
    }


    inner class MainRecyclerViewAdapter :
        RecyclerView.Adapter<MainRecyclerViewAdapter.MainViewHolderClass>() {

        inner class MainViewHolderClass(rowMainBinding: RowMainBinding) :
            RecyclerView.ViewHolder(rowMainBinding.root) {
            val titleTextView: TextView
            val descriptionTextView: TextView
            init {
                titleTextView = rowMainBinding.titleTextView
                descriptionTextView = rowMainBinding.descriptionTextView
            }
        }

            override fun onCreateViewHolder(
                parent: ViewGroup,
                viewType: Int
            ): MainViewHolderClass {
                val rowMemoBinding = RowMainBinding.inflate(layoutInflater)
                val mainViewHolderClass = MainViewHolderClass(rowMemoBinding)

                rowMemoBinding.root.layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                return mainViewHolderClass
            }

            override fun onBindViewHolder(holder: MainViewHolderClass, position: Int) {
                holder.titleTextView.text = searchItems[position].title
                holder.descriptionTextView.text = searchItems[position].description
            }

            override fun getItemCount(): Int {
                return searchItems.size
            }


        }

    override fun onResume() {
        super.onResume()
        // 리사이클러뷰 갱신
        binding.recyclerViewMain.adapter?.notifyDataSetChanged()
    }
}

data class SearchItem(
    val title: String,
    val link: String,
    val description: String,
)
data class ApiResponse(
    val items: List<SearchItem>,
)
