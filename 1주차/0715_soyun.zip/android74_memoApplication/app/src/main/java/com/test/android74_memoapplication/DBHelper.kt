package com.test.android74_memoapplication


import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


class DBHelper(context:Context) : SQLiteOpenHelper(context, "Memo.db", null, 1) {

    override fun onCreate(sqliteDatabase: SQLiteDatabase?) {

        // 디비 내 메모 테이블 생성(번호,제목,내용,날짜)
        val sql = """create table MemoTable
            (idx integer primary key autoincrement,
            title text not null,
            content text not null,
            dateData date not null)
        """.trimIndent()

        sqliteDatabase?.execSQL(sql)
    }


    override fun onUpgrade(sqliteDatabase: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }
}